$(document).ready(function() {
	$myCarousel = $('#myCarousel');
	$myCarousel.carousel({
		interval: 	5000,
		pause: 		'hover'
	});
});